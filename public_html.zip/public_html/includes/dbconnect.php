<?php
  $database_host = 'sql170.main-hosting.eu';
  $database_username = 'u708089898_charge';
  $database_password = 'chargewiz';
  $database_name = 'u708089898_chargingwizard';

  $conn = new mysqli($database_host, $database_username, $database_password, $database_name);


 ?>
